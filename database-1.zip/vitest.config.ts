import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    globals: true,
    environment: 'node',
    coverage: {
      provider: 'v8',
      reporter: ['text', 'json', 'html'],
      exclude: [
        'node_modules/',
        'dist/',
        'prisma/',
        '**/*.spec.ts',
        '**/*.test.ts',
      ],
    },
    include: ['src/**/*.{test,spec}.ts'],
  },
});
