import { Router } from "express";
import { authMiddleware } from "../../middlewares/auth.middleware.js";
import {
  getDashboardStats,
  getUserStats,
  getProjectStats,
  getStartupStats,
  getInvestmentStats,
  getFinancialStats,
  getSupportStats,
  getSystemStats,
  refreshCache
} from "../../controllers/analytics/analytics.controller.js";

const router = Router();

router.use(authMiddleware as any);

router.get("/dashboard", getDashboardStats);
router.get("/users", getUserStats);
router.get("/projects", getProjectStats);
router.get("/startups", getStartupStats);
router.get("/investments", getInvestmentStats);
router.get("/financials", getFinancialStats);
router.get("/support", getSupportStats);
router.get("/system", getSystemStats);
router.post("/refresh", refreshCache);

export default router;
