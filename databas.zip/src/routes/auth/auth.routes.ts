import { Router } from "express";
import {
  login,
  register,
  logout,
  refresh,
  me,
  forgotPassword,
  resetPassword,
  changePassword,
} from "../../controllers/auth/auth.controller.js";
import { authMiddleware } from "../../middlewares/auth.middleware.js";

const router = Router();

router.post("/login", login);
router.post("/register", register);
router.post("/logout", authMiddleware as any, logout as any);
router.post("/refresh", refresh);
router.post("/forgot-password", forgotPassword);
router.post("/reset-password", resetPassword);
router.post("/change-password", authMiddleware as any, changePassword as any);
router.get("/me", authMiddleware as any, me as any);

export default router;
